﻿using System.IO;
using System.Text.RegularExpressions;

namespace FourthTask.File
{
	internal class ManageFile
	{
		private Regex checkReadingMatrix;
		public ManageFile()
		{
			checkReadingMatrix = new Regex(@"\{\{[0-9,]+[0-9]\},+{[0-9,]+[0-9]\},*\}");
		}

		/// <summary>
		/// Read by file
		/// </summary>
		/// <param name="path">Input parameter - path to file</param>
		/// <returns></returns>
		public string ReadFile(string path)
		{
			using (StreamReader sr = new StreamReader(path, System.Text.Encoding.Default))
			{
				string line;
				while ((line = sr.ReadLine()) != null)
				{
					return line;
				}
			}
			return "";
		}

		/// <summary>
		/// Validate data
		/// </summary>
		/// <param name="matrix">Input parameter - matyrix</param>
		/// <returns></returns>
		public bool ValidateData(string matrix)
		{
			if (!checkReadingMatrix.IsMatch(matrix))
				return false;
			return true;
		}
	}
}
