﻿namespace FourthTask.GaussMethod
{
	public interface IGoussMethod
	{
		/// <summary>
		/// This method calculates
		/// </summary>
		/// <param name="sender">First input parameter</param>
		/// <param name="slae">The second input parameter is SLAE</param>
		void Process(object sender, Slae slae);
	}
}
