﻿using System.Linq;
using System.Text.RegularExpressions;

namespace FourthTask.GaussMethod
{
	public class Slae
	{
		public double[][] Matrix { get; set; }
		private (int, int) _size;
		public (int, int) Size => _size;

		public Slae(string matrix)
		{
			TransformIntoMatrix(matrix);
			FindSize();
		}

		/// <summary>
		/// This method copies the contents of the matrix into a new matrix, 
		/// that is, it creates a copy
		/// </summary>
		/// <returns></returns>
		public double[,] Copy()
		{
			double[,] array = new double[_size.Item1, _size.Item2];

			for (int i = 0; i < _size.Item1; i++)
			{
				for (int j = 0; j < _size.Item2; j++)
				{
					array[i, j] = Matrix[i][j];
				}
			}

			return array;
		}

		/// <summary>
		/// This method copies the data from the current matrix into 
		/// a new square matrix for further calculations
		/// </summary>
		/// <returns></returns>
		public double[,] CopySquare()
		{
			double[,] array = new double[_size.Item1, _size.Item1];

			for (int i = 0; i < _size.Item1; i++)
			{
				for (int j = 0; j < _size.Item1; j++)
				{
					array[i, j] = Matrix[i][j];
				}
			}

			return array;
		}

		/// <summary>
		/// This method creates an array of free matrix coefficients
		/// </summary>
		/// <returns></returns>
		public double[] CopyColumn()
		{
			double[] array = new double[_size.Item1];

			for (int i = 0; i < _size.Item1; i++)
			{
				array[i] = Matrix[i][_size.Item2 - 1];
			}

			return array;
		}

		/// <summary>
		/// This method determines the size of the matrix
		/// </summary>
		public void FindSize()
		{
			_size.Item1 = Matrix.GetLength(0);
			_size.Item2 = Matrix[0].Length;
		}

		/// <summary>
		/// This method translates the received data into a matrix
		/// </summary>
		/// <param name="matrix"></param>
		public void TransformIntoMatrix(string matrix)
		{
			matrix = matrix.Replace(" ", string.Empty);

			Matrix =
			Regex.Matches(matrix, @"{(\d+,?)+},?").Cast<Match>()
			.Select(m =>
			   Regex.Matches(m.Groups[0].Value, @"\d+(?=,?)").Cast<Match>()
			   .Select(ma => double.Parse(ma.Groups[0].Value)).ToArray())
				.ToArray();
		}
	}
}
