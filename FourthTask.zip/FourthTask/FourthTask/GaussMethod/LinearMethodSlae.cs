﻿using System.Diagnostics;

namespace FourthTask.GaussMethod
{
	public class LinearMethodSlae : IGoussMethod
	{
		public override string ToString()
		{
			return "Linear";
		}

		/// <summary>
		/// This method already produces the computational process of the SLAE by the linear method
		/// </summary>
		/// <param name="sender">The first input parameter is sender </param>
		/// <param name="slae">The second input parameter is the SLAE to be calculated</param>
		public void Process(object sender, Slae slae)
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			double[,] matrix = slae.Copy();
			EliminateElementsAheadForLinerMethod(matrix, slae.Size.Item1);
			double[] results = BackSubstitution(matrix, slae.Size.Item1);
			stopwatch.Stop();
			ResaltMethodSlae.SetResults(ToString(), results, stopwatch.ElapsedMilliseconds);
		}

		/// <summary>
		/// This method does forward liquidation
		/// </summary>
		/// <param name="matrix">The first input parameter is the matrix itself</param>
		/// <param name="orderOfTheMatrix">The second input parameter is matrix order</param>
		private void EliminateElementsAheadForLinerMethod(double[,] matrix, int orderOfTheMatrix)
		{
			for (int i = 0; i < orderOfTheMatrix; i++)
			{
				for (int j = i + 1; j < orderOfTheMatrix; j++)
				{
					double ratio = matrix[j, i] / matrix[i, i];

					for (int k = 0; k <= orderOfTheMatrix; k++)
					{
						matrix[j, k] -= ratio * matrix[i, k];
					}
				}
			}
		}

		/// <summary>
		/// This method performs the reverse replacement of elements
		/// </summary>
		/// <param name="matrix">The first input parameter is the matrix itself</param>
		/// <param name="orderOfTheMatrix">The second input parameter is matrix order</param>
		/// <returns></returns>
		private static double[] BackSubstitution(double[,] matrix, int orderOfTheMatrix)
		{
			double[] x = new double[orderOfTheMatrix];
			x[orderOfTheMatrix - 1] = matrix[orderOfTheMatrix - 1,
				orderOfTheMatrix] / matrix[orderOfTheMatrix - 1, orderOfTheMatrix - 1];

			for (int k = orderOfTheMatrix - 2; k >= 0; k--)
			{
				double sum = 0;

				for (int j = k + 1; j < orderOfTheMatrix; j++)
				{
					sum += matrix[k, j] * x[j];
				}

				x[k] = (matrix[k, orderOfTheMatrix] - sum) / matrix[k, k];
			}

			return x;
		}

	}
}
