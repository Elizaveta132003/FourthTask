﻿using System.Diagnostics;
using System.Threading.Tasks;

namespace FourthTask.GaussMethod
{
	public class DistributedMethodSlae : IGoussMethod
	{
		public override string ToString()
		{
			return "Distributed";
		}

		/// <summary>
		///  This method already produces the computational process of the SLAE by the distributed method
		/// </summary>
		/// <param name="sender">The first input parameter is sender</param>
		/// <param name="slae">The second input parameter is the SLAE to be calculated</param>
		public void Process(object sender, Slae slae)
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			double[,] squreMatrix = slae.CopySquare();
			double[] freeMembersInMatrix = slae.CopyColumn();
			EliminateElementsAheadForDistributedMethod(squreMatrix, freeMembersInMatrix, slae.Size.Item1);
			double[] results = BackSubstitution(squreMatrix, freeMembersInMatrix, slae.Size.Item1);
			stopwatch.Stop();
			ResaltMethodSlae.SetResults(ToString(), results, stopwatch.ElapsedMilliseconds);
		}


		/// <summary>
		/// This method performs the reverse replacement of elements
		/// </summary>
		/// <param name="firstMatrix">The first input parameter is a square matrix</param>
		/// <param name="arr">The second input parameter is a column vector of free coefficients</param>
		/// <param name="orderOfTheMatrix">The third input parameter is the order of the matrix</param>
		private void EliminateElementsAheadForDistributedMethod(double[,] firstMatrix, double[] arr, int orderOfTheMatrix)
		{
			for (int k = 0; k < orderOfTheMatrix; k++)
			{
				Parallel.For(k + 1, orderOfTheMatrix, j =>
				{
					double d = firstMatrix[j, k] / firstMatrix[k, k];

					for (int i = k; i < orderOfTheMatrix; i++)
					{
						firstMatrix[j, i] = firstMatrix[j, i] - d * firstMatrix[k, i];
					}

					arr[j] = arr[j] - d * arr[k];
				});
			}
		}

		/// <summary>
		/// This method performs the reverse replacement of elements
		/// </summary>
		/// <param name="firstMatrix">The first input parameter is a square matrix</param>
		/// <param name="arr">The second input parameter is a column vector of free coefficients</param>
		/// <param name="orderOfTheMatrix">The third input parameter is the order of the matrix</param>
		/// <returns></returns>
		private double[] BackSubstitution(double[,] firstMatrix, double[] arr, int orderOfTheMatrix)
		{
			double[] x = new double[orderOfTheMatrix];

			for (int k = orderOfTheMatrix - 1; k >= 0; k--)
			{
				double d = 0;

				for (int j = k + 1; j < orderOfTheMatrix; j++)
				{
					double s = firstMatrix[k, j] * x[j];
					d = d + s;
				}

				x[k] = (arr[k] - d) / firstMatrix[k, k];
			}

			return x;
		}
	}
}
