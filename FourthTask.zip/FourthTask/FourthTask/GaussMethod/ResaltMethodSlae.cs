﻿using System;

namespace FourthTask.GaussMethod
{
	public class ResaltMethodSlae
	{
		static private string _solution;
		static public string Solution => _solution;
		static public string TimeUsage => _timeUsage;

		static private string _timeUsage;

		/// <summary>
		/// This method receives the result of solving the SLAE
		/// </summary>
		/// <param name="sender">The first input parameter is sender</param>
		/// <param name="results">The second input parameter is the results</param>
		/// <param name="time">The third input parameter is the computation time</param>
		public static void SetResults(string sender, double[] results, long time)
		{
			if (_solution == null)
			{
				_solution = String.Join(",", results);
			}

			if (_timeUsage == null)
			{
				_timeUsage += sender + ":" + $"{Convert.ToString(time)}";
			}
			else
			{
				_timeUsage += ", " + sender + ":" + $"{Convert.ToString(time)}";
			}
		}

		/// <summary>
		/// This method produces the results of calculations
		/// </summary>
		/// <returns></returns>
		public static string GetResults() => _solution + ". " + _timeUsage;

		/// <summary>
		/// This method resets everything, a kind of reboot
		/// </summary>
		public static void Reset()
		{
			_solution = null;
			_timeUsage = null;
		}
	}
}
