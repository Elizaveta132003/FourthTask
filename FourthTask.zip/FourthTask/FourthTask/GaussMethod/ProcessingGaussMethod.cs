﻿using System;


namespace FourthTask.GaussMethod
{
	public class ProcessingGaussMethod
	{
		private event EventHandler<Slae> dataCalculateEvent;

		public event EventHandler<Slae> DataCalculateEvent
		{
			add { dataCalculateEvent += value; }
			remove { dataCalculateEvent -= value; }
		}

		/// <summary>
		/// This method performs the Gauss method
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="matrix"></param>
		public void GaussSolve(object obj, string matrix)
		{
			dataCalculateEvent?.Invoke(this, new Slae(matrix));
		}

		/// <summary>
		/// This method subscribes to an event
		/// </summary>
		/// <param name="process">Input parameter - Gauss method</param>
		public void ConnectProcess(IGoussMethod process)
		{
			DataCalculateEvent += process.Process;

		}

		/// <summary>
		/// This method unsubscribes from the event
		/// </summary>
		/// <param name="process">Input parameter - Gauss method</param>
		public void DisconnectProcess(IGoussMethod process)
		{
			DataCalculateEvent -= process.Process;
		}
	}
}
