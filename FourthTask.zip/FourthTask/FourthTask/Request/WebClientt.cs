﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace FourthTask.Request
{
	public class WebClientt
	{
		private int _port;

		private bool _noDataToSend;

		private bool _isCreated;

		private IPEndPoint _ip;

		private List<string> results;

		private Socket _socket;

		public IPEndPoint Ip => _ip;
		public Socket Socket => _socket;

		public WebClientt(int port)
		{
			_port = port;
		}

		/// <summary>
		/// Create Web Client
		/// </summary>
		public void CreateWebClient()
		{
			if (_isCreated == false)
			{
				_ip = new IPEndPoint(IPAddress.Loopback, _port);
				_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				_isCreated = true;
			}
		}

		/// <summary>
		/// Start client
		/// </summary>
		public void StartClient()
		{
			if (_isCreated == true)
			{
				Socket.Connect(Ip);

				while (true)
				{
					string dataToSend = GetData();
					int bytesRead = 0;
					byte[] data = Encoding.UTF8.GetBytes(dataToSend);
					Socket.Send(data);

					data = new byte[1024];
					StringBuilder builder = new StringBuilder();

					do
					{
						bytesRead = Socket.Receive(data, data.Length, 0);
						results.Add(Encoding.UTF8.GetString(data));
					}
					while (Socket.Available > 0);

					if (_noDataToSend)
						StopServer();
				}
			}
		}

		/// <summary>
		/// Stop client
		/// </summary>
		public void StopServer()
		{
			Socket.Shutdown(SocketShutdown.Both);
			Socket.Close();
			_socket = null;
			_isCreated = false;
		}

		/// <summary>
		/// Get data
		/// </summary>
		/// <returns></returns>
		public string GetData()
		{
			string data = "";
			return data;
		}

	}
}
