﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace FourthTask.Request
{
	internal class ServerHttp : Server
	{
		private string _possibleHeader;

		private string _possibleBody;

		private byte[] _data;

		private int _currentCounter;

		public ServerHttp(int port) : base(port)
		{

			_currentCounter = 0;
		}

		/// <summary>
		/// Validate http request
		/// </summary>
		/// <param name="data">Input parameter-data</param>
		/// <returns></returns>
		public bool ValidateHttpRequest(byte[] data)
		{
			_data = data;
			foreach (var piece in data)
			{
				_currentCounter++;
				byte[] buffer = new byte[1];
				buffer[0] = piece;
				_possibleHeader += Encoding.UTF8.GetString(buffer);
				if (_possibleHeader.Contains("\r\n\r\n"))
				{
					return true;
				}
			}
			ResetReceivedData();
			return false;
		}

		/// <summary>
		/// Parse body
		/// </summary>
		/// <returns></returns>
		public string ParseBody()
		{

			int contentLength = FindLenghOfTheContent();
			byte[] body = new byte[contentLength];
			Array.Copy(_data, _currentCounter, body, 0, contentLength);
			_currentCounter = 0;
			_possibleBody += Encoding.ASCII.GetString(body);
			return _possibleBody;
		}

		/// <summary>
		/// Find lenght of the content
		/// </summary>
		/// <returns></returns>
		public int FindLenghOfTheContent()
		{
			Regex reg = new Regex("\\\r\nContent-Length: (.*?)\\\r\n");
			Match m = reg.Match(_possibleHeader);
			int contentLength = int.Parse(m.Groups[1].ToString());
			return contentLength;
		}

		/// <summary>
		/// Resert received data
		/// </summary>
		public void ResetReceivedData()
		{
			_possibleBody = null;
			_possibleHeader = null;
			_currentCounter = 0;
		}

	}
}
