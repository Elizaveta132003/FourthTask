﻿using FourthTask.GaussMethod;
using System;
using System.Text;

namespace FourthTask.Request
{
	internal class ProcessData
	{
		private Server _server;

		private WebClientt _client;

		private event EventHandler<string> dataReadyToCalculateEvent;

		public event EventHandler<string> DataReadyToCalculateEvent
		{
			add { dataReadyToCalculateEvent += value; }
			remove { dataReadyToCalculateEvent -= value; }
		}

		private ServerHttp _http;

		private ProcessingGaussMethod _gauss;
		public Server Server { get => _server; set => _server = value; }
		public WebClientt Client { get => _client; set => _client = value; }
		public ProcessingGaussMethod Gauss { get => _gauss; }

		public ProcessData(ProcessingGaussMethod gaussian, ServerHttp http, Server server, WebClientt client)
		{
			_server = server;

			_client = client;

			_gauss = gaussian;

			server.DataReceivingEvent += Process;

			_http = http;
		}

		/// <summary>
		/// This method, according to the input data, determines which method will occur.
		/// </summary>
		/// <param name="sender">The first input parameter is sender</param>
		/// <param name="data">The second input is the data</param>
		public void Process(object sender, byte[] data)
		{
			if (_http.ValidateHttpRequest(data))
			{
				string matrix = _http.ParseBody();
				dataReadyToCalculateEvent?.Invoke(this, matrix);
			}
			else
			{
				dataReadyToCalculateEvent?.Invoke(this, Encoding.UTF8.GetString(data));
			}

		}
	}
}
