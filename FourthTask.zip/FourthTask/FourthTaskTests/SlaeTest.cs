using FourthTask.GaussMethod;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FourthTask.Tests
{
	[TestClass]
	public class SlaeTest
	{
		public Slae slae;

		[TestInitialize]
		public void SlaeInitialization()
		{
			string matrix = "{{ 2, 5, 8, 2 },{ 3, 5, 8, 2 },{ 4, 5, 8, 2 }}";
			slae = new Slae(matrix);
		}

		[TestMethod]
		public void DuplicateMatrix_MakeCopyOfTheGivenMatrix_MethodCompletedWithoutExeption()
		{
			double[,] matrix = slae.Copy();
		}

		[TestMethod]
		public void CopyToSquareMatrix_CopyThisMatrixIntoSquareMatrix_MethodCompletedWithoutExeption()
		{
			double[,] matrix = slae.CopySquare();
		}

		[TestMethod]
		public void CopyingMatrixColumn_CopyTheLastColumnOfOurMatrix_MethodCompletedWithoutExeption()
		{
			double[] arr = slae.CopyColumn();
		}

		[TestMethod]
		public void FindingTheSizeOfTheMatrix_FindingTheSizeOfOurMatrix_MethodCompletedWithoutExeption()
		{
			slae.FindSize();
		}
	}
}
