﻿using FourthTask.GaussMethod;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FourthTask.Tests
{
	[TestClass]
	public class DistributedMethodTests
	{
		private Slae SlaeInitialization()
		{
			string matrix = "{{ 2, 5, 8, 2 },{ 3, 5, 8, 2 },{ 4, 5, 8, 2 }}";
			Slae slae = new Slae(matrix);
			return slae;
		}

		[TestMethod]
		public void Process_TheProcessOfCalculatingSlaeByDistributedMethod_MethodCompletedWithoutExeption()
		{
			var slae = SlaeInitialization();
			DistributedMethodSlae method = new DistributedMethodSlae();
			Object obj = 0;
			method.Process(obj, slae);
		}
	}
}
