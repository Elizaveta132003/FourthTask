﻿using FourthTask.Request;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FourthTask.Tests
{
	[TestClass]
	public class WebClientTests
	{
		public WebClientt client;

		[TestInitialize]
		public void TestInitialize()
		{
			int port = 8000;
			client = new WebClientt(port);
		}

		[TestMethod]
		public void CreatServer_ShouldCreateTheServer()
		{
			bool expected = true;
			bool actual = true;

			client.CreateWebClient();
			if (client.Ip == null & client.Socket == null)
				actual = false;

			Assert.AreEqual(expected, actual);
		}
	}
}
