﻿using FourthTask.GaussMethod;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FourthTask.Tests
{
	[TestClass]
	public class LinearMethodTests
	{
		private Slae SlaeInitialization()
		{
			string matrix = "{{ 2, 5, 8, 2 },{ 3, 5, 8, 2 },{ 4, 5, 8, 2 }}";
			Slae slae = new Slae(matrix);
			return slae;
		}

		[TestMethod]
		public void Process_TheProcessOfCalculatingSlaeByLinearMethod_MethodCompletedWithoutExeption()
		{
			var slae = SlaeInitialization();
			LinearMethodSlae method = new LinearMethodSlae();
			Object obj = 0;
			method.Process(obj, slae);
		}
	}
}
